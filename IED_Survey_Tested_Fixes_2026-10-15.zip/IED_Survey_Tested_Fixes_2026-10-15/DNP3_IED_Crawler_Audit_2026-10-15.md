# IED security crawler: evidence audit and completion direction

Date: 15 October 2026. Repository: https://github.com/akekulip/ied-security-survey

Audited revision: `8e520f1fce8ae7e54654c9eda8e0e3ef518e6a35`.

## Decision

Keep the existing crawler. Its collection, caching, source hashes, bounded fetching and review schema are useful. Correct its evidence interpretation and finish a small, explicit second pass. A new crawler, a larger census or an autonomous research framework is unnecessary for this supporting section of NOMAD.

The present output is **not ready to support the earlier paper paragraph**. In particular, a missed D400 statement contradicts the claim about all 31 discontinued entries, missing documentation is labelled plaintext, and all 820 review rows remain AI drafts. These are substantive problems, rather than formatting issues.

Local corrections are supplied in the accompanying patch package. No changes were committed or pushed to GitHub.

## 1. What Dr. Lin asked for

The meeting asks for a short supporting study: first check prior research, then use public vendor information to identify relevant devices, their security capabilities and configuration requirements. Record vendors, search terms, models, counts and method so the supporting material can go in the appendix. Keep this bounded; the switch mechanism remains the main contribution.

Three questions need different evidence:

| Question | Suitable evidence | What the crawler can establish |
|---|---|---|
| Does a product support protection of a particular control protocol? | Applicable vendor manual, profile or configuration guide, with model/firmware conditions | Documented capability, including explicit unsupported statements |
| Is protection enabled by default, optional or licensed? | Explicit setting/default and activation instructions | Documented default and requirements for that version |
| Do operators actually enable it; how much deployed traffic is plaintext? | Deployment measurements or an appropriate operator study | Not established by product documentation |

Dr. Lin explicitly allowed the evidence to go against a convenient argument. If many devices support security, preserve that result and use other evidence to discuss adoption. The visible draft fragment asserts that plaintext remains prevalent; it does not provide a measurement. The longer paragraph previously proposed in this conversation was an AI draft, not evidence of the full current Overleaf text.

## 2. What was checked

- Retrieved the pinned code, tests, study files and complete sample-run records from GitHub, checking their Git blob identities.
- Reproduced the original `dnp3.csv`, `findings.json`, `devices.csv` and `findings_table.csv` byte for byte.
- Ran the original 88 tests successfully.
- Checked all 308 retained extracted-text digests against their source records: no mismatches.
- Retrieved 13 selected original documents, approximately 152 MB, and checked their SHA-256 hashes. Selected quoted PDF passages also matched freshly parsed pages under the repository's existing whitespace/hyphen normalization.
- Reproduced five classification mistakes and an extracted-text evidence-binding gap using synthetic fixtures. Added regressions and prepared a local correction; all 99 tests pass.
- Re-read relevant primary vendor sources and checked the existence and scope of earlier research below.

This was not a fresh crawl of every product or a complete independent semantic review of all 820 rows. The full 308-source raw-cache `verify`/`rebuild`/`replay` sequence was not run here. Unit-test messages about replay refer to test fixtures. None of the draft rows has been changed to author-confirmed.

## 3. A concrete error in the earlier conclusion: GE D400

The sample's retained vendor page says D400 manufacturing has been discontinued (`html-block:7` and `:64`). Its retained brochure, **page 1**, explicitly describes a TLS tunnel carrying DNP3/TCP, Modbus/TCP and IEC 104 from a master station to the D400.

Evidence identity:

- Product: `ge_multilin_d400_legacy`.
- Source: `e9650803a7d08f102554`, `pdf-page:1`.
- SHA-256: `d6d2dd564878318f2e49ee97009eb2f8216515edb840ae1ba8230b54334c8a57`.
- Vendor brochure: https://www.gevernova.com/electrification/sites/default/files/2025-09/Multilin-D400-Brochure-EN-12806D-Hybrid-202505-001.pdf

Therefore, **“none of the 31 discontinued devices documents protection of its control traffic” is false for the retained sample**. The brochure establishes family-level capability, not whether every old D400 firmware supports it or any deployed unit enables it.

The cause is traceable. `iedsurvey/leads.py::candidates` records three TLS matches on the page but gives only the context around the first one. That first context concerns management access. The later, decisive control-traffic statement is absent from the short context. The earlier AI second pass also missed it. The supplied correction retains all distinct contexts on a page and adds a separate, explicitly draft D400 review correction.

The original appendix's count of six entries documenting control-traffic encryption becomes **at least seven** after this one correction, including at least one discontinued entry. This is a corrected draft count, not a finished review or an estimate of deployed devices.

## 4. Other errors and gaps

### Missing evidence becomes a claim of plaintext

`iedsurvey/findings.py::dnp3_security` and its display labels turn several weaker facts into stronger conclusions:

| Input evidence | Original conclusion | Correct interpretation |
|---|---|---|
| No applicable security evidence | Plaintext | Capability not established |
| Integrity only | Authenticated, not encrypted | Integrity documented; authentication and encryption not established |
| Authentication only | Not encrypted | Encryption not established by that finding |
| External encryption for a different/unspecified protocol | DNP3 protected externally | DNP3 applicability not established |
| One security feature explicitly unsupported | DNP3 not protected | That specific feature is unsupported |

The original DNP3 subset contains 32 entries. Its 24 entries labelled plaintext are not 24 demonstrated plaintext deployments.

After the classification correction and the D400 review correction, the draft subset is:

| Documented result | Entries |
|---|---:|
| DNP3 TLS/IPsec protection | 5 |
| DNP3 authentication; encryption not established | 1 |
| Control-traffic encryption; DNP3 scope not established | 1 |
| External encryption; DNP3 scope not established | 2 |
| DNP3 security not established from retrieved documents | 23 |
| Total | 32 |

This table remains incomplete: the known RTAC guide below was not associated with the sample. Do not present it as the definitive security-capable fraction.

### The study has not completed the defaults question

In the original review, 48 of 49 positive capability rows leave the default `not_assessed`; the remaining row concerns enabled management HTTPS. There are no disabled-by-default findings in that machine-readable table, despite examples mentioned elsewhere.

The retained Rockwell manual, publication **2080-UM002S-EN-E, April 2026, printed page 89**, documents Micro870 DNP3 Secure Authentication as disabled by default. It supports SAv2 and SAv5; when authentication is enabled, the version selector defaults to version 2. Do not conflate those two defaults.

Source: https://literature.rockwellautomation.com/idc/groups/literature/documents/um/2080-um002_-en-e.pdf

The document is already cached under a Micro830-associated source. The review validator only accepts evidence associated with the reviewed product, so the applicable Micro870 default did not enter its row. Add a verified product-document association or an explicit seed for Micro870; do not merely paste a quote from a different product's record. Conversely, a multi-product manual does not establish that every listed controller supports DNP3.

ABB's AC500 documentation independently gives a disabled-by-default Secure Authentication example. ABB is outside this five-vendor sample and must remain a separately cited example:
https://help.plc.abb.com/AB281_en/adcfee22f1883359ea6f8c9974f7ea51_4_en_us.html

Neither example establishes how operators configure deployed equipment.

### Recall is known to be incomplete

The SEL RTAC sample retrieved two flyers, while this project's pilot already found SEL publication 112760. The white paper, **“Leveraging Security – Using the SEL RTAC's Built-In Security Features,”** discusses SCADA encryption on pages 9–10 and DNP3 TLS configuration in Figure 9. Its title is not the Figure 9 caption used in an earlier note.

Source: https://selinc.com/api/download/112760/

Reuse and associate this known source before doing more broad discovery. Record its family/firmware applicability, default and activation separately; do not silently add it to counts from a run that did not retrieve it.

### Scope and sampling limit the conclusions

- The frame has 484 catalogue entries; the stratified sample has 99. It is not a sample of installed devices. Selection fractions vary roughly from 3.9% to 100%; unweighted sample percentages cannot estimate all 484 entries or the industry.
- All 99 identity-level fields are unset. Families and models are mixed; A8000 and CP-8050 appear separately with shared documentation. Call the unit a catalogue entry until identity and overlap are resolved.
- “Currently supported” is often inferred from a current listing without a discontinuation notice. Prefer “currently listed/sold” unless support is explicitly established. It does not establish a recent product generation.
- Vendor-discontinued is not end of support, an old architecture, or absence of cryptographic capability. The legacy grouping was widened after the first results were observed; disclose the change and use the precise lifecycle term.
- Documentation depth differs sharply: Schneider's 29 entries have 29 extracted web pages and no extracted PDF pages; GE's 29 entries have 163 extracted documents. Do not compare vendor capability rates as though recall were equal.
- Silence in a full manual is still not an explicit vendor denial. All 820 review rows remain drafts; an AI re-read does not make them author-confirmed.

### Evidence binding needs one additional check

A synthetic reproduction changed a saved extracted segment and inserted a quote not present in the fetched document. Original `verify` accepted the unchanged raw cache, and `report --require-evidence` accepted the modified segment. They checked different parts of the chain.

The local patch checks extracted text against the recorded text digest before review resolution and binds report inputs and outputs in a receipt. All 308 actual sample digests matched; this finding is a verification gap, not evidence that these study records were fabricated. A normalized text digest is not complete page-layout attestation. Full raw-byte verification and offline regeneration remain necessary for release.

## 5. Does relevant earlier research exist?

Yes. It supports a narrower, defensible motivation, rather than a percentage of deployed plaintext traffic.

| Source | What it can support | Boundary |
|---|---|---|
| CISA, *Barriers to Secure OT Communication: Why Johnny Can't Authenticate*, February 2026 | Existing qualitative work on barriers to secure OT communication | Not an industry plaintext-traffic census |
| Michael Clark's 13 October 2026 firsthand account of participating in that CISA work | Confirms asset-owner interviews across several sectors and adoption barriers | Use the research/method account; do not substitute its OPC UA promotion for a deployment measurement |
| NIST SP 800-82r3 | Legacy resource constraints and difficulties adding security while preserving operational requirements | Not a measured percentage of insecure IEDs |
| Rockwell Micro870 and ABB AC500 vendor instructions | Concrete authentication defaults and activation requirements | Version-specific examples, not operator behaviour or all-device defaults |
| Erba, Müller and Tippenhauer, *Security Analysis of Vendor Implementations of the OPC UA Protocol for Industrial Control Systems* (2021) | Precedent for systematic examination of vendor security implementations; the abstract reports 48 products/libraries and security issues | OPC UA scope; not a DNP3/IED deployment-prevalence study |

Primary links:

- CISA record: https://www.cisa.gov/resources-tools/resources/barriers-secure-ot-communication-why-johnny-cant-authenticate
- Firsthand participant account: https://www.automation.com/article/why-johnny-can-t-authenticate-but-asset-owners-can-secure-ot-deployments
- NIST final publication: https://csrc.nist.gov/pubs/sp/800/82/r3/final
- Author preprint: https://arxiv.org/abs/2104.06051

Verification boundary: the CISA page/PDF returned access errors during this audit. The publication is indexed and the participant account was read; the repository also retains a previous checking record. I do not claim a fresh complete read of the CISA PDF. Likewise, the earlier NIST Table 18/19 page checks remain prior-work records; the official publication and indexed legacy constraints were checked here. The particular CMU paper Dr. Lin showed remains unidentified. Do not label any convenient paper as that paper.

Avoid saying SAv5 and CIP Security individually date to the early 2000s. Version matters. In particular, qualify the authentication-without-confidentiality statement as **SAv5**, rather than making it universal across future DNP3 security revisions. Authentication without confidentiality can leave data readable, but authenticated protocols can also constrain in-network rewriting; NOMAD compatibility requires separate validation.

## 6. Small completion plan

1. Apply the tested classification, context and provenance patch. Preserve the original run/review/report. Add a dated erratum for D400 and remove the plaintext inference from the current manuscript and appendix.
2. Rebuild the old sample offline from its existing cache under extraction revision 1.4.1, into a new folder. Check raw and text identities, rebind the review, and regenerate the worksheet. This is reuse, not a new 99-device crawl.
3. Finish a focused second pass over the existing 32 DNP3 entries. First associate RTAC 112760 and the applicable Micro870 manual. For unresolved entries, allow at most two targeted official manual/profile/security-guide seeds per entry. Record inaccessible or absent documentation as unknown.
4. Generate one readable row per entry/protocol: lifecycle; authentication, integrity and encryption independently; scope; firmware/licence conditions; default; activation; evidence; review status. Reuse the existing schema and interface table. A single “strongest security” bucket is only a display aid.
5. Have an author verify the rows used for publication, particularly positive findings, defaults and explicit unsupported statements. Publish a smaller reviewed subset if necessary. Do not bulk-confirm AI unknowns to clear a gate.
6. Produce the main paragraph, appendix and counts through one checked-in command with input hashes and review status. The existing `paper_appendix.tex` says generated, but its generation script is not present in the audited tree; repair that reproducibility gap.

The repository is currently public although several documents call it private, and roughly 1.27 GB of the 1.51 GB tracked tree is fetched-source cache. Reconcile the stated distribution policy before a release. No visibility change, deletion or history rewrite was performed here. Keep a small code/test package and a separate documented evidence bundle for future releases; there is no need to destroy the current evidence to simplify the workflow.

## 7. Wording the evidence can support now

Proposed replacement, with bibliography entries added in the manuscript:

> Secure protocol options do not guarantee that deployed control traffic is protected. CISA's operator-interview work identifies practical barriers to adopting secure OT communication, while NIST describes constraints on adding security to legacy systems. Vendor documentation also shows that capabilities and defaults differ: some products document encrypted control protocols, and Micro870 and AC500 instructions document disabled-by-default DNP3 Secure Authentication. We therefore distinguish documented capability, default configuration and deployed use. Our documentation survey addresses the first two; it does not measure plaintext prevalence in operational networks.

After author review, add a short description of the bounded catalogue sample and place the evidence table and method in the appendix. Do not restore the “none of 31” statement, interpret unknowns as insecure, or claim a measured plaintext percentage.

## Supplied implementation status

The patch corrects the five summary inferences, retains multiple keyword contexts, validates recorded extracted-text hashes, adds report provenance and an opt-in `--require-confirmed` publication gate, and bumps the extraction revision. It includes 11 additional regression tests; **99 tests pass, exit 0**. A two-row D400 correction is supplied as an additive AI draft, with an input-hash-checked application script. The complete-cache rebuild, source associations, final human review and appendix generator are the next bounded work, not claimed complete.

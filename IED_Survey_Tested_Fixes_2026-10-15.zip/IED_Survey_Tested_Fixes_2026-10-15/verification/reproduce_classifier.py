"""Print the five evidence-scope cases against an explicitly chosen repository checkout."""
import argparse
import json
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('repository')
args = parser.parse_args()
sys.path.insert(0, args.repository)
from iedsurvey.findings import Findings, DNP3_KINDS

def row(feature, protocol='DNP3', status='supported', interface='DNP3 server', basis=None):
    return dict(product_id='p', interface_class='control_protocol', feature=feature, protocol=protocol,
                interface=interface, status=status, support_basis=basis or ['built_in'])

cases = {
    'no_security_evidence': [],
    'integrity_only': [row('integrity')],
    'external_gateway_other_protocol': [row('encryption', 'Modbus', 'conditional', 'Modbus server', ['external_gateway'])],
    'only_SA_explicitly_unsupported': [row('dnp3_secure_authentication', status='explicitly_unsupported')],
    'authentication_positive_encryption_not_assessed': [row('authentication')],
}
results = {}
for name, rows in cases.items():
    found = Findings.__new__(Findings)
    found.claims = rows
    key, _ = found.dnp3_security('p')
    results[name] = dict(key=key, label=dict(DNP3_KINDS)[key])
print(json.dumps(results, indent=2))

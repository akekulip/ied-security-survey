"""Report whether a chosen checkout rejects modified extracted text; uses synthetic local files only."""
import argparse
import contextlib
import io
import json
import sys
import tempfile
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('repository', type=Path)
args = parser.parse_args()
sys.path[:0] = [str(args.repository), str(args.repository / 'tests')]
from support import SurveyCase
from iedsurvey.store import load, dump
from iedsurvey.report import report
from iedsurvey.runs import verify
from iedsurvey.text import text_digest

with tempfile.TemporaryDirectory() as td:
    p = Path(td)
    with contextlib.redirect_stdout(io.StringIO()):
        SurveyCase().reviewed_run(p)
    source = next(s for s in load(p / 'run/sources.json') if s['product_id'] == 'a')
    path = p / 'run' / (source['id'] + '.segments.json')
    text = load(path)
    inserted = 'DNP3 traffic uses IPsec on every connection by default.'
    text[0]['text'] += ' ' + inserted
    dump(path, text)
    rows = load(p / 'reviews.json')
    rows[0]['evidence'][0]['quote'] = inserted
    dump(p / 'reviews.json', rows)
    result = dict(recorded_text_sha256=source['text_sha256'], modified_text_sha256=text_digest(text))
    with contextlib.redirect_stdout(io.StringIO()):
        verify(p / 'run', p / 'cache')
        result['raw_cache_verify_accepted'] = True
        try:
            report(p / 'run', p / 'reviews.json', p / 'report', require_evidence=True)
        except ValueError as error:
            result.update(report_require_evidence_accepted=False, refusal=str(error))
        else:
            result['report_require_evidence_accepted'] = True
    print(json.dumps(result, indent=2))

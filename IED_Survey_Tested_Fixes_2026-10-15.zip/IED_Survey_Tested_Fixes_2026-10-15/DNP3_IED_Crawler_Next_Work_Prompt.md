# Finish the IED documentation study for NOMAD

Work in `akekulip/ied-security-survey`. This task concerns the supporting documentation study, not the DNP3 switch implementation.

Audited base: `8e520f1fce8ae7e54654c9eda8e0e3ef518e6a35`. Read the accompanying `DNP3_IED_Crawler_Audit_2026-10-15.md` and the patch package README first. Inspect current HEAD and existing changes; preserve work that landed after this base. Do not assume the patch applies unchanged if the repository has advanced.

## Objective and scope

Dr. Lin requested a bounded, reproducible supporting study for NOMAD: establish which relevant vendor products document protection of control traffic, what defaults and activation requirements are documented, and what existing research says about adoption. Record vendors, keywords, models, source pages, dates and hashes. Keep detailed method and evidence in the appendix. The crawler does not measure deployed plaintext prevalence.

Retain the five vendors and historical 99-entry sample. Complete a focused second pass over its existing 32 DNP3 entries. Do not build another framework, launch a fresh census, add an LLM review swarm or touch the switch/testbed. Reuse the crawler, cache, review schema and interface table.

## Milestone 1 — apply and verify the concrete corrections

1. Review `crawler_fixes.patch` with `git apply --check`, then apply it if compatible. It corrects unknown/plaintext and protocol-scope inferences, keeps every distinct keyword context, validates recorded extracted-text digests, adds a report receipt and an optional `--require-confirmed` publication gate. Extraction revision becomes 1.4.1.
2. Run `python3 -m unittest discover -s tests -v` and use the actual exit code. The supplied tree passed 99 tests. Preserve the failing-before/passing-after regression evidence.
3. Run `python3 apply_d400_correction.py /path/to/repository` from the package. It checks the original review hash and writes a separate review file. It must never overwrite the historical AI draft or mark anything author-confirmed.
4. Add a dated correction to the study README/second-pass record and update the current paper/appendix text: the retained D400 brochure explicitly documents control-protocol TLS on page 1. Therefore the earlier claim about none of 31 discontinued entries is false. Corrected counts are provisional draft lower bounds, not final findings.
5. Search current report/appendix generation paths for the same invalid inferences. Missing documentation must remain unknown. Authentication does not prove lack of encryption; integrity alone does not prove authentication. External protection needs protocol-specific applicability.

## Milestone 2 — reuse the evidence and fix recall

Use the full cache already in the user's checkout. Run raw-byte verification, offline rebuild into a new folder, and replay against that rebuilt run; retain commands, versions, exit codes and hashes. Do not replay an old extraction-1.4.0 run with 1.4.1 and report the expected mismatch as corruption.

Use `rebind` only when its unchanged-text conditions hold. Validate all quotes again against located segments. Compare all rebuilt text digests, not only keyword counts: the existing replay command's final comparison focuses on lead files and is not a complete independent comparison of saved segment files. Stop publication on unexplained mismatches.

Resolve the known source-association gaps before fetching anything new:

- SEL RTAC: publication 112760, *Leveraging Security – Using the SEL RTAC's Built-In Security Features*, SCADA encryption pages 9–10 and Figure 9. Reuse the pilot source. Establish which family/firmware it applies to.
- Micro870: retained manual 2080-UM002S-EN-E, printed page 89. Associate it with the applicable product, despite its original Micro830 fetch association. Record Secure Authentication disabled by default separately from the version-selector default of 2 when enabled. Do not infer DNP3 support for every product in the multi-product manual.

Prefer the existing explicit-seed/reuse mechanism if sufficient. If a shared-document association is needed, implement a small audited mapping from immutable document hash to applicable product/model/firmware, with supporting evidence. Never weaken product-source validation globally.

For remaining unresolved DNP3 entries, fetch at most two targeted official manuals, device profiles or security guides per entry, honoring current limits and robots handling. Log exact queries/seed URLs and why each was chosen. A login wall, missing manual or exhausted budget is an unknown, not a security denial. Finish this bounded pass; do not repeatedly broaden the search until a desired result appears.

## Milestone 3 — produce the simple, correct output

Derive one readable row per catalogue entry/control protocol from the existing schema:

`entry/model | precise lifecycle | protocol | authentication | integrity | encryption | built-in/external/management scope | firmware/licence conditions | default | activation | source/page/hash | reviewer/status`

Keep these properties independent. Use supported, conditional, explicitly unsupported and unknown accurately. Separate management HTTPS/SSH from control traffic. A SAv5 authentication finding is not evidence of encrypted payloads; a version-specific fact is not universal across every DNP3 security revision.

Identify family-versus-model entries and overlap; do not silently delete sampled entries. Label the unit “catalogue entry” until resolved. Use currently listed/sold and vendor-discontinued where those are the facts. Do not equate these with modern hardware, end of support, or absent security.

Keep unweighted sample counts and their denominators. Do not extrapolate percentages to the 484-entry frame, vendor populations or installed devices. Show document-coverage limitations. Preserve the original sample, results and post-result definition-change history.

## Milestone 4 — finish the paper evidence, then stop

1. Create one checked-in command that generates the final summary, evidence table and LaTeX appendix from named input files. Include a receipt for inputs, script/dependency versions and outputs. Do not maintain an untracked one-off appendix generator.
2. Obtain actual author review for the published rows. Do not change `review_status` to confirmed merely because another AI has reread a quote. If all 99 entries cannot be verified, publish an explicitly narrower reviewed subset and retain the exploratory sample separately. The publication gate must reject incomplete review.
3. Add a short prior-work note: CISA's qualitative adoption-barrier work, NIST's legacy constraints, the applicable vendor defaults, and relevant vendor-implementation research. The particular CMU paper remains unidentified; record that instead of guessing or spending the night searching for it.
4. Write a short main-paper paragraph separating capability, default and deployment. Use qualitative adoption evidence; do not claim measured plaintext prevalence. Remove inaccurate blanket chronology about SAv5/CIP Security dating to the early 2000s.

## Acceptance and delivery

- Tests pass; all classification and context regressions remain active.
- Original evidence is preserved; the new run, review and report are distinguishable and hash-bound.
- D400, RTAC and Micro870 are traced to applicable source evidence; no contradictory “none of 31” or unknown-equals-plaintext statement remains in the current manuscript output.
- Every published finding has the correct product/protocol scope, quote/page/hash, conditions/default status and actual review provenance.
- Full-cache verification and regeneration results are recorded honestly, including failures and inaccessible documents.
- Main paragraph, appendix, table and counts regenerate through one documented command.
- The public/private description mismatch is reported; do not change repository visibility, delete evidence or rewrite history without direction. Plan a small reproducibility package with permitted source distribution rather than automatically redistributing every fetched PDF.

Finish with a compact checkpoint: completed items, changed files, test commands/results, exact output locations, remaining unknowns and author decisions. Commit coherent changes under applicable repository instructions if authorized; do not push or alter defaults automatically. Completion is a trustworthy bounded supporting study, not a claim to have measured real-world plaintext traffic.

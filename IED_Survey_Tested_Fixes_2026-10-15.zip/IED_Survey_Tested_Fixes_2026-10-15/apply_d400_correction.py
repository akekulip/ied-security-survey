"""Apply the two supplied D400 corrections to a new AI-draft review, never to the historical review."""
import argparse
import copy
import hashlib
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repository', type=Path)
    parser.add_argument('--out', type=Path, help='new output path; defaults to the correction record destination')
    args = parser.parse_args()
    correction = json.loads((Path(__file__).resolve().parent / 'd400_correction.json').read_text())
    source = args.repository / correction['input_review']
    raw = source.read_bytes()
    if hashlib.sha256(raw).hexdigest() != correction['input_sha256']:
        parser.error('historical review changed; inspect and rebase the correction instead of overwriting')
    rows = json.loads(raw)
    for replacement in correction['replacements']:
        candidates = [i for i, row in enumerate(rows) if row['product_id'] == replacement['product_id']
                      and row['feature'] == replacement['feature'] and row['status'] == 'unknown'
                      and not row.get('interface_class')]
        if len(candidates) != 1:
            parser.error('expected exactly one historical unknown row for ' + replacement['feature'])
        new = copy.deepcopy(replacement)
        new['evidence'] = correction['shared_capability_evidence']
        if new.get('review_status') != 'draft':
            parser.error('correction must remain a draft')
        rows[candidates[0]] = new
    dest = args.out if args.out else args.repository / correction['output_review']
    dest.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive creation is intentional: preserve any existing review and its provenance.
    with dest.open('x', encoding='utf-8') as f:
        json.dump(rows, f, indent=2, ensure_ascii=False)
        f.write('\n')
    print(f'Wrote {dest}; {len(rows)} rows; all supplied corrections remain AI drafts')


if __name__ == '__main__':
    main()

# Tested IED survey corrections — 15 October 2026

Repository base: https://github.com/akekulip/ied-security-survey/commit/8e520f1fce8ae7e54654c9eda8e0e3ef518e6a35

This is a small source patch, an additive **AI-draft** review correction, and audit/reproduction evidence. No remote changes were made. No fetched vendor PDF, raw cache or full repository is redistributed here.

Read `DNP3_IED_Crawler_Audit_2026-10-15.md`; use `DNP3_IED_Crawler_Next_Work_Prompt.md` for the bounded follow-up.

## Apply

Inspect HEAD and your local changes first. If the repository has advanced, rebase the small diff rather than discarding newer work. From the repository root, substituting the absolute package path:

```bash
git apply --check /absolute/package/crawler_fixes.patch
git apply /absolute/package/crawler_fixes.patch
python3 -m pip install -r requirements.txt
python3 -m unittest discover -s tests -v
python3 /absolute/package/apply_d400_correction.py "$PWD"
```

The correction script checks the exact historical review SHA-256. It creates `study/catalogue_2026-10-13/review/reviews_ai_audit_2026-10-15.json` exclusively and refuses to overwrite a file. The two changed rows remain drafts. If that output already exists, inspect it; do not delete it just to make the command run. Use `--out /new/path.json` when a distinct candidate file is appropriate.

Original suite: 88 passing tests. Corrected suite: 99 passing tests. All are Python `unittest` tests, not live-device tests. Extraction revision changes from 1.4.0 to 1.4.1, so old runs must not be advertised as replayed with the new rule set.

## Reproduce the corrected draft table

From the repository root, after applying the correction:

```bash
python3 survey.py report \
  --run data/runs/sample_2026-10-13_v2_0 \
  --reviews study/catalogue_2026-10-13/review/reviews_ai_audit_2026-10-15.json \
  --source-notes study/catalogue_2026-10-13/review/source_notes_ai_draft.json \
  --device-notes study/catalogue_2026-10-13/review/device_notes_ai_draft.json \
  --require-evidence \
  --out study/catalogue_2026-10-13/reports/audit_draft_2026-10-15
```

This reuses recorded segments and validates their text digests and quotes. It is **not** a claim that the current extractor regenerated the complete raw cache. With `--require-confirmed` added, it must refuse this still-draft review. That is expected.

`corrected_dnp3_preview.csv` gives the regenerated 32-entry draft view without duplicating vendor passages. The full evidence is obtainable through the command above. The RTAC recall gap has deliberately not been silently added to this preview.

## Complete-cache verification, on the user's existing full checkout

Run each command separately and check its exit status before continuing. Choose output paths that do not already exist.

```bash
python3 survey.py verify --run data/runs/sample_2026-10-13_v2_0 --cache data/cache
python3 survey.py rebuild --run data/runs/sample_2026-10-13_v2_0 --cache data/cache --out data/runs/sample_audit_2026-10-15
python3 survey.py replay --run data/runs/sample_audit_2026-10-15 --cache data/cache --out data/runs/sample_audit_replay_2026-10-15
python3 survey.py rebind --reviews study/catalogue_2026-10-13/review/reviews_ai_audit_2026-10-15.json --old data/runs/sample_2026-10-13_v2_0 --run data/runs/sample_audit_2026-10-15 --out study/catalogue_2026-10-13/review/reviews_audit_rebound_2026-10-15.json
```

These complete-cache commands were **not run for the entire sample in this audit**. Verify every rebuilt source text digest and revalidate located quotes before treating the regenerated output as publication evidence. The existing replay's comparison focuses on lead files, so its success alone is not a comparison of every saved segment file.

## Small reproductions

The portable scripts take an explicit repository path and only use synthetic fixtures. Run each on a separate baseline checkout and on the patched checkout:

```bash
python3 /absolute/package/verification/reproduce_classifier.py /absolute/repository
python3 /absolute/package/verification/reproduce_evidence_binding.py /absolute/repository
```

The baseline accepts modified extracted text; the patched report refuses it. See saved baseline JSON and the new regression tests. The scripts print the observed outcome and exit normally in either case; they are diagnostic demonstrations, not pass/fail gates.

## Contents and boundaries

- `crawler_fixes.patch`: nine changed/new code, test and README paths; no historical study files overwritten.
- `d400_correction.json`, `apply_d400_correction.py`: two proposed replacement rows sharing one source passage, with a pinned original-review hash.
- `audit_summary.json`, `corrected_dnp3_preview.csv`: draft counts and explicit review/verification status.
- `verification/`: original and patched test logs, baseline red regressions, hash checks, selected-source metadata, and portable synthetic reproductions.
- `MANIFEST.sha256`: hashes of the delivered package files.

The publication gate is opt-in, and it checks recorded review states; it cannot establish that a human really performed a review. Source-text digest checks cover recorded hashes and do not make unsigned files tamper-proof. No deployment/plaintext prevalence is inferred. Follow-up source associations, bounded targeted retrieval, human review and an appendix generator remain work to do.

# Crawler code corrections for 0f13499

Base commit: `0f134991a2d48fab4cff0f74888701801e05d700`.

Read `IED_Crawler_Code_Review_0f13499.md` for the findings and direct completion instructions. This package contains a local proposed patch; it has not been committed or pushed. It adds no dependencies, keeps extraction revision 1.4.1, and proposes tool version 2.3.1.

## Apply and test

Inspect HEAD and existing work first. If the repository advanced, preserve that work and rebase only the relevant changes. From the repository root, substituting the package path:

```bash
git apply --check /absolute/package/code_fixes.patch
git apply /absolute/package/code_fixes.patch
python3 -m pip install -r requirements.txt
python3 -m unittest discover -s tests -v
python3 -m compileall -q iedsurvey tests
```

The supplied tree passes 119 tests. The patch was also applied to a fresh copy of the pinned source and checked for exact resulting bytes. Historical data, reviews, pilot fixtures and generated outputs are not modified by the patch. The existing root package checksum ledger is documented as historical rather than overwritten.

The patch covers:

- recovery from interrupted multi-file checkpoints;
- pinned resume configuration, approvals and execution environment;
- a completion marker written after templates;
- content-hash validation of raw cache entries;
- same-run reuse of a fetched URL with independent product association;
- reuse of fresh shared-PDF extraction through a hash-checked segment reference;
- consistent paragraph labels and reviewed default fields;
- a short implementation/recovery guide in the README.

Old partial runs without a resume contract must start afresh using verified retained bytes. Completed historical runs can still be verified and replayed. Resumed runs flag that their network request log may be incomplete across the interruption.

## Full-cache final check

These commands use existing bytes and make no vendor requests. Select a replay output path that does not exist, and record each exit status:

```bash
python3 survey.py verify --run data/runs/sample_targeted_2026-10-15 --cache data/cache
python3 survey.py replay --run data/runs/sample_targeted_2026-10-15 --cache data/cache --out data/runs/codefix_replay_0f13499
```

The complete 325-source raw-document replay was not repeated in this audit. The real retained 400-page manual benchmark and replay did pass, and paper output generation was checked against all the retained sample's extracted sources/reviews.

Regenerate paper output into a new directory with the unchanged inputs:

```bash
python3 survey.py paper \
  --run data/runs/sample_targeted_2026-10-15 \
  --reviews study/catalogue_2026-10-13/review/reviews_ai_draft_2026-10-15.json \
  --source-notes study/catalogue_2026-10-13/review/source_notes_ai_draft.json \
  --device-notes study/catalogue_2026-10-13/review/device_notes_ai_draft.json \
  --out study/catalogue_2026-10-13/paper_codefix_0f13499
```

The counts remain 6 / 1 / 3 / 2 / 1 / 19. The paragraph and receipts change; the summary, table and appendix were byte-identical to the pushed outputs. Adding `--require-confirmed` must still refuse the 821 draft rows. Do not mark AI rows confirmed to clear the gate.

## Reproduce the real-document benchmark

The benchmark scripts take explicit paths. `--baseline` can be a small copy of the old source code, rather than another copy of the entire evidence tree. Both implementations need the pinned Python requirements available. The input raw cache is read only.

```bash
python3 /absolute/package/benchmark_shared_pdf.py \
  --baseline /absolute/baseline_source \
  --candidate /absolute/patched_source \
  --run /absolute/full_repository/data/runs/sample_targeted_2026-10-15 \
  --cache /absolute/full_repository/data/cache \
  --out /absolute/new_diagnostic_output
```

It uses the two existing associations of the retained 400-page Micro830/850/870 manual, compares baseline/candidate rebuilds byte for byte, and runs candidate replay. It does not fetch anything or modify either implementation. No vendor PDF is included in this ZIP. The recorded result is one benchmark pair, not a full-survey performance estimate.

## Verification files

- `verification/regressions_before.log`: nine reproduced failures against the base implementation.
- `verification/pdf_reuse_before.log`: two parse-count failures before the optimization.
- `verification/tests_final.log`: all 119 tests passing.
- `verification/benchmark_result_final.json`: actual parse counts, times, source-code identities and output equality.
- `verification/paper_validation.json`: equal repeated generation, unchanged counts and publication refusal.
- `verification/package_ledger_check.json`: the checked historical-ledger discrepancies.
- `patch_metadata.json`: base commit, changed paths and their input/output hashes.
- `MANIFEST.sha256`: checksums of this package's files.

After the offline verification and author review, finish the paper integration. These corrections do not require another vendor census, new crawler architecture or deletion of historical evidence.

# IED crawler code review and tested corrections

Audited base: `0f134991a2d48fab4cff0f74888701801e05d700` in https://github.com/akekulip/ied-security-survey

Date: 15 October 2026. All proposed changes are local. Nothing was committed or pushed.

## Outcome

The existing implementation is small enough to keep. The useful changes concern evidence recovery, provenance, repeated work and accurate output generation. A broad repository refactor is unnecessary for completing Dr. Lin's supporting documentation study.

I reproduced nine failures in interruption, cache, download-reuse and paragraph tests before fixing them. Two further tests demonstrated repeated PDF parsing. The proposed tree passes **119 tests, exit 0**, compared with 105 on the pushed base. Python compilation also passes.

## Findings and fixes

| Priority | Location | Reproduced behaviour | Proposed correction |
|---|---|---|---|
| High | `crawl.py`: checkpoint/resume | Interrupting after `sources.json` but before lead-file writes loses the earlier source's keyword leads on resume. Normal completion can then hide the omission until replay. | Reconstruct derived leads from saved sources and segments after checking their raw/text hashes. Do not trust independently checkpointed lead files as the authority. |
| High | `crawl.py`: resume | A paused run accepts a changed approval list, extractor version or code identity. Its final manifest can describe a mixture of executions as one run. | Persist `crawl_contract.json` before requests; require the same configuration, approval input, reused source records, code, extractor, dependencies and interpreter on resume. Refuse an unpinned legacy partial run. |
| High | `crawl.py::finish` | An error writing a final template leaves a completion manifest, and resume refuses the supposedly complete run. | Write the completion manifest after every template. The interrupted run can then resume successfully. |
| Medium | `fetch.py::store`, `crawl.py::obtain` | A same-length damaged cache entry is retained; reuse can extract its changed content while retaining the original raw SHA-256 identity. | Check the bytes, not just length. A fresh known response repairs an incorrect cache entry, and reuse refuses a mismatch before extracting it. This was a synthetic failure reproduction, not observed corruption in the study. |
| Medium | `crawl.py::obtain` | Two products using the same newly fetched URL download it twice within one run. | Add successful downloads to the existing reuse index while keeping separate product source IDs, scope and leads. The regression goes from two requests to one. |
| Medium | `extract.py`, `crawl.py`, `runs.py` | Shared PDFs are parsed once per product association during crawl, rebuild and replay. | Reuse a fresh same-run PDF extraction through a checked on-disk reference keyed by raw SHA-256. Keep only a small metadata index in memory; recompute product-specific leads and alias matches. Replay reuses its own fresh extraction, not the old run's saved text. |
| Medium | `paper.py` | The paragraph changes unknown encryption to no encryption, and uncertain DNP3 applicability to an absence claim. Existing tests require those phrases. Default prose also searches for a word in the quote instead of using the reviewed default field. | Render the existing `DNP3_KINDS` vocabulary without merging distinct external-protection categories. Use the reviewed default field. Update the tests to preserve uncertainty. |

The patch proposes tool version **2.3.1** and keeps extraction revision **1.4.1**: the PDF optimization changes repeated work, not extraction or lead semantics.

## Measured efficiency

The retained targeted run has 166 extracted PDF associations but only 139 unique PDF blobs. Repeated parsing accounts for **7,028 of 20,530 PDF page visits**. Reusing each unique PDF would remove those repeated page visits per complete pass; this is a workload count, not a measured whole-run time reduction.

A real-data benchmark used the retained 400-page Micro830/Micro850/Micro870 manual, SHA-256 `0f6f1715c95afefc8813cd311af7da5859139c073b8554ad3e52a28ac38d1bdb`, with its two existing product associations:

| Operation | PDF reader calls | Elapsed time |
|---|---:|---:|
| Baseline rebuild | 2 | 30.76 s |
| Proposed rebuild | 1 | 15.68 s |
| Proposed replay | 1 | 15.64 s |

Both product source records, both segment files, `candidates.json` and `statement_leads.json` are **byte-identical between the rebuilds**. The proposed replay passed. No vendor request was made. This is one matched benchmark pair; do not extrapolate its roughly twofold speedup to the full survey.

The shared extraction cache verifies the raw bytes supplied to it and the exact bytes of its fresh segment reference. Tests reject a changed raw body and changed page locations. Product associations and model-alias matches remain separate. It introduces no dependency or persistent extraction-cache format.

## Reproducibility checks

- Original pushed suite: 105 passing tests.
- First failing regression run: 114 tests, nine failures.
- PDF parsing regression run before optimization: two failures, each showing two reader calls rather than one.
- Proposed complete suite: **119 passing tests, exit 0**.
- `python3 -m compileall -q iedsurvey tests`: exit 0.
- Real retained-manual rebuild/replay benchmark: pass, with equal evidence outputs.
- The four paper files regenerate identically across two proposed-code runs. Summary, table and appendix retain their pushed bytes; only the paragraph deliberately changes.
- DNP3 category counts remain **6 / 1 / 3 / 2 / 1 / 19**. All 821 rows remain drafts; the publication gate still refuses output.

The full 325-extracted-source raw-document replay was not repeated here. The previous independent check established that all referenced raw blobs are tracked, but that is different from downloading and reparsing the entire cache. The final offline check on the user's complete checkout is specified below.

## Small implementation choices worth keeping

- Keep `Findings` and the existing interface table as the authority for report and paper output. Avoid separate classifier rules in each renderer.
- Keep the content-addressed raw cache and immutable historical runs. Separate source association from document identity.
- Keep the new exact page/text replay checks and fail-closed publication gate.
- Limit implementation searches to `iedsurvey/` and `tests/`. Read individual study records when needed; feeding the entire cache or 821-row JSON into every coding prompt adds cost without improving a focused change.
- Keep one owner per output directory. Atomic JSON files are already implemented; they do not make a group of independently written checkpoint files a transaction.

One wording detail: the approved list gates document entry URLs, while the fetcher also makes robots requests and follows recorded vendor-domain redirects. Describe that scope precisely; an assertion that every HTTP address literally occurs in the document list would be stronger than the implementation. This does not invalidate the recorded bounded pass.

The root `PACKAGE_SHA256.json` is also stale as a current-code inventory: four materialized entries have different hashes,
and its `tests/test_survey.py` entry no longer exists in the pinned Git tree. Fourteen pilot entries still match. The
patch documents its historical status; it does not rewrite that record or the pilot. Current code/run/report receipts
remain the relevant provenance.

## Direct instructions for Claude

1. Read this review and the package README. Check HEAD and existing changes. The patch is based on `0f134991a2d48fab4cff0f74888701801e05d700`; preserve any later work.
2. Run `git apply --check` on `code_fixes.patch`. Apply the compatible changes without overwriting historical data, reviews, pilot fixtures or paper output archives. Do not create another crawler framework or begin another broad search.
3. Run `python3 -m unittest discover -s tests -v` and check its exit code. The proposed tree has 119 tests. Run the syntax check as recorded above.
4. On the existing full cache, run one offline `verify` and `replay` of `data/runs/sample_targeted_2026-10-15` with the proposed code, using a new replay directory. Retain exit codes and timing. Extraction revision remains 1.4.1, so a fresh crawl is unnecessary. Investigate an actual mismatch before proceeding.
5. Regenerate the current report/paper outputs into a new folder with the same run, reviews, source notes and device notes. Require unchanged category counts, preserved draft status and publication refusal. The paragraph and receipts should change; historical outputs remain preserved. Compare two new generations for reproducibility.
6. Keep the old package checksum ledger clearly labelled historical. If publishing a new code bundle, generate a new checksum manifest for that bundle. Do not edit old run identities to pretend they used the new code.
7. Commit coherent changes under the repository's actual current instructions if authorized. Push only within Philip's current authorization. Report the tested commit, output paths, offline replay outcome and any remaining limitation.

Then complete the author review and manuscript integration. The CMU-paper identification and an expanded vendor search are not prerequisites for landing these implementation corrections.

## Boundaries after the fix

A resumed run marks `request_log_may_be_incomplete`: a process can stop with an HTTP request in flight before the next checkpoint. Recovery does not invent missing request history. Do not use such a run to claim an exhaustive request count. The code deliberately refuses to resume an old partial run without a pinned execution contract; start a new run using verified retained bytes instead. Completed old runs still support offline verification and replay.

These changes improve the tool. They do not turn AI drafts into author review, show deployed security settings, or establish plaintext prevalence.

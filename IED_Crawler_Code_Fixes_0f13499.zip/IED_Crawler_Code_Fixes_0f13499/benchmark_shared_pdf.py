"""Reproduce the retained 400-page shared-manual comparison offline, without modifying either checkout or raw cache."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--baseline', required=True, type=Path, help='baseline source checkout')
parser.add_argument('--candidate', required=True, type=Path, help='patched source checkout')
parser.add_argument('--run', required=True, type=Path, help='retained sample_targeted_2026-10-15 run')
parser.add_argument('--cache', required=True, type=Path, help='existing full data/cache')
parser.add_argument('--out', required=True, type=Path, help='new diagnostic output directory, preferably outside Git')
args = parser.parse_args()
for name in ('baseline', 'candidate', 'run', 'cache', 'out'):
    setattr(args, name, getattr(args, name).resolve())
sha = '0f6f1715c95afefc8813cd311af7da5859139c073b8554ad3e52a28ac38d1bdb'
if hashlib.sha256((args.cache / sha).read_bytes()).hexdigest() != sha:
    parser.error('the retained Micro830/850/870 manual is missing or changed')
args.out.mkdir(parents=True, exist_ok=False)
inputs = args.out / 'input'
inputs.mkdir()
sources = [s for s in json.loads((args.run / 'sources.json').read_text(encoding='utf-8'))
           if s.get('sha256') == sha and s['status'] == 'extracted']
if len(sources) != 2 or any(s.get('pages') != 400 for s in sources):
    parser.error('expected the two retained product associations of the 400-page manual')
cfg = json.loads((args.run / 'config.json').read_text(encoding='utf-8'))
cfg['products'] = [p for p in cfg['products'] if p['id'] in {s['product_id'] for s in sources}]
cfg['sampling'] = 'Code benchmark only: two existing associations of one retained manual; not survey findings.'
for name, value in [('config.json', cfg), ('sources.json', sources), ('requests.json', [])]:
    (inputs / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
driver = Path(__file__).resolve().parent / 'benchmark_driver.py'
results = {}
for name, repo, mode, run in [('baseline', args.baseline, 'rebuild', inputs),
                              ('candidate', args.candidate, 'rebuild', inputs),
                              ('candidate_replay', args.candidate, 'replay', args.out / 'candidate')]:
    with (args.out / (name + '.log')).open('w', encoding='utf-8') as log:
        result = subprocess.run([sys.executable, str(driver), str(repo), mode, str(run), str(args.cache),
                                 str(args.out / name), str(args.out / (name + '.json'))],
                                env=os.environ.copy(), stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        raise SystemExit(f'{name} failed with {result.returncode}; inspect its log')
    results[name] = json.loads((args.out / (name + '.json')).read_text(encoding='utf-8'))
files = ['sources.json', 'candidates.json', 'statement_leads.json'] + [s['id'] + '.segments.json' for s in sources]
checks = {name: (args.out / 'baseline' / name).read_bytes() == (args.out / 'candidate' / name).read_bytes() for name in files}
if not all(checks.values()):
    raise SystemExit('evidence outputs differ; investigate before accepting the optimization')
results.update(output_bytes_equal=checks, document_sha256=sha, pages=400,
               note='One benchmark pair, not a whole-survey performance estimate. No network requests are made.')
(args.out / 'comparison.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8')
print(json.dumps(results, indent=2))

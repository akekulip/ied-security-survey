"""Measure actual PDF parses for a local retained-document fixture; never fetches a network resource."""
import argparse
import json
from pathlib import Path
import sys
import time
from unittest.mock import patch

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('repository', type=Path)
parser.add_argument('mode', choices=('rebuild', 'replay'))
parser.add_argument('run', type=Path)
parser.add_argument('cache', type=Path)
parser.add_argument('out', type=Path)
parser.add_argument('result', type=Path)
args = parser.parse_args()
sys.path.insert(0, str(args.repository))
from pypdf import PdfReader
from iedsurvey import runs
from iedsurvey.store import SCRIPT_SHA256
from iedsurvey.vocabulary import VERSION

start = time.perf_counter()
with patch('pypdf.PdfReader', wraps=PdfReader) as reader:
    getattr(runs, args.mode)(args.run, args.cache, args.out)
elapsed = time.perf_counter() - start
result = {'mode': args.mode, 'seconds': elapsed, 'pdf_reader_calls': reader.call_count,
          'repository': str(args.repository), 'network_requests': 0,
          'tool_version': VERSION, 'script_sha256': SCRIPT_SHA256}
args.result.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
